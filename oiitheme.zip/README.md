Open Integrity Index Theme
==========================

Based on Drupal Boostrap module.
Configured with Bootstrap Source Files method described "https://drupal.org/node/1978010"
